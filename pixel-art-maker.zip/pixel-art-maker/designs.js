// Select color input
// Select size input
var color, height, width;

// When size is submitted by the user, call makeGrid()

$('#sizePicker').submit(function (event){
    event.preventDefault();
    height = $('#inputHeight').val();
    width = $('#inputWidth').val();
    makeGrid(height, width);
})

function makeGrid(h ,w) {
    $('tr').remove();

// make grid of h height and w width
    for (var i = 1; i <= h; i++) {
        $('#pixelCanvas').append('<tr id=tr' + i + '></tr>');
        for (var j = 1; j <= w; j++) {
            $('#tr' + i).append('<td></td>');
        }
    }

// apply color from color picker
    $('td').click(function addColor() {
        color = $('#colorPicker').val();

        if ($(this).attr('style')) {
            $(this).removeAttr('style')
        } else {
            $(this).attr('style', 'background-color:' + color);
        }
    })
}
